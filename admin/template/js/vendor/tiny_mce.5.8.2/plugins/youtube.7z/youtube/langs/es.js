tinymce.addI18n('es', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "Insertar un vídeo de YouTube",
    'Youtube URL'       : 'Enlace para compartir',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx ó http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : 'Ancho',
    'height'            : 'Alto',
    'ratio'             : 'Relación',
    'ratio16by9'        : '16:9',
    'ratio4by3'         : '4:3',
    'autoplay'          : 'Autoplay',
    'Related video'     : 'Vídeos relacionados',
    'HD video'          : 'Ver en HD',
    'cancel'            : 'Cancelar',
    'Insert'            : 'Insertar'
});
