tinymce.addI18n('ja', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "Youtube埋め込み",
    'Youtube URL'       : 'URL',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx または http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : '幅',
    'height'            : '高さ',
    'ratio'             : '比',
    'ratio16by9'        : '16:9',
    'ratio4by3'         : '4:3',
    'autoplay'          : '自動再生',
    'Related video'     : '関連動画を表示',
    'HD video'          : 'HD再生を行う',
    'cancel'            : 'キャンセル',
    'Insert'            : '挿入する'
});
