tinymce.addI18n('it', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "Inserisci un video di Youtube",
    'Youtube URL'       : 'Condividi URL',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx o http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : 'Larghezza',
    'height'            : 'Altezza',
    'ratio'             : 'Rapporto',
    'ratio16by9'        : '16:9',
    'ratio4by3'         : '4:3',
    'autoplay'          : 'Autoplay',
    'Related video'     : 'Video correlati',
    'HD video'          : 'Guarda in HD',
    'cancel'            : 'Annullare',
    'Insert'            : 'Inserisci'
});
