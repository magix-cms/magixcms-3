tinymce.addI18n('tr', {
    'YouTube Tooltip' : "YouTube",
    'YouTube Title'   : "YouTube Videosu Ekle",
    'Youtube URL'     : 'Youtube Linki',
    'Youtube ID'      : 'http://youtu.be/xxxxxxxx yada http://www.youtube.com/watch?v=xxxxxxxx gibi',
    'width'           : 'Genişlik',
    'height'          : 'Yükseklik',
    'ratio'           : 'Oran',
    'ratio16by9'      : '16:9',
    'ratio4by3'       : '4:3',
    'autoplay'        : 'Otomatik Başlat',
    'Related video'   : 'İlgili video',
    'HD video'        : 'HD Olarak İzle',
    'cancel'          : 'iptal',
    'Insert'          : 'Ekle'
});
